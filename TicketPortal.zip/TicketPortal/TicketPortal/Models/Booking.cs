﻿using System;
using System.Collections.Generic;

namespace TicketPortal.Models;

public partial class Booking
{
    public int BookingId { get; set; }

    public string? BookingDate { get; set; }

    public int? NoOfSeatsBooked { get; set; }

    public int? PassengerId { get; set; }

    public int? BusId { get; set; }

    public virtual Bus? Bus { get; set; }

    public virtual Passenger? Passenger { get; set; }
}
