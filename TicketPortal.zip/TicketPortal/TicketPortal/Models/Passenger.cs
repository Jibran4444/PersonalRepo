﻿using System;
using System.Collections.Generic;

namespace TicketPortal.Models;

public partial class Passenger
{
    public int PassengerId { get; set; }

    public string? PassengerName { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
}
