﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Libary.Models;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;

namespace Libary.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorsController : ControllerBase
    {
        private readonly LibraryContext _context;

        public AuthorsController(LibraryContext context)
        {
            _context = context;
        }

        // GET: api/Authors
        [HttpGet]
        public  ActionResult<IEnumerable<Author1>> GetAuthors()
        {
            string path1 = System.IO.File.ReadAllText("D:\\dotNet\\laibary\\Laibary\\LibaryClass\\Libary\\databse\\data.json");
                List<Author1> p = null;


            if (_context.Author1s.Any())
            {
                p = JsonConvert.DeserializeObject<List<Author1>>(path1);
                if (p != null)
                {

                    foreach (Author1 a in p)
                    {
                        _context.Author1s.Add(a);
                        Console.WriteLine(a.AutherName);
                        _context.SaveChanges();
                    }
                }


            }
               
                return _context.Author1s.ToList();
            

                
            


           
           
        }

    // GET: api/Authors/5
    [HttpGet("{id}")]
    public async Task<ActionResult<Author>> GetAuthor(int id)
    {
        if (_context.Authors == null)
        {
            return NotFound();
        }
        var author = await _context.Authors.FindAsync(id);

        if (author == null)
        {
            return NotFound();
        }
    
            return author;
        }

        // PUT: api/Authors/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAuthor(int id, Author author)
        {
            if (id != author.AutherId)
            {
                return BadRequest();
            }

            _context.Entry(author).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AuthorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Authors
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Author>> PostAuthor(Author author)
        {
          if (_context.Authors == null)
          {
              return Problem("Entity set 'LibraryContext.Authors'  is null.");
          }
            _context.Authors.Add(author);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (AuthorExists(author.AutherId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetAuthor", new { id = author.AutherId }, author);
        }

        // DELETE: api/Authors/5
        [HttpDelete("{id}"),Authorize(Roles ="admin")]
        public async Task<IActionResult> DeleteAuthor(int id)
        {
            if (_context.Authors == null)
            {
                return NotFound();
            }
            var author = await _context.Authors.FindAsync(id);
            if (author == null)
            {
                return NotFound();
            }

            _context.Authors.Remove(author);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AuthorExists(int id)
        {
            return (_context.Authors?.Any(e => e.AutherId == id)).GetValueOrDefault();
        }
    }
}
