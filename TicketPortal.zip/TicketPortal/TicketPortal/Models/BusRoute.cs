﻿using System;
using System.Collections.Generic;

namespace TicketPortal.Models;

public partial class BusRoute
{
    public int RouteId { get; set; }

    public string? PickupPoint { get; set; }

    public string? DropPoint { get; set; }

    public virtual ICollection<Bus> Buses { get; set; } = new List<Bus>();
}
