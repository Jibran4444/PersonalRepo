﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TicketPortal.Models;

public partial class TicketDbContext : DbContext
{
    public TicketDbContext()
    {
    }

    public TicketDbContext(DbContextOptions<TicketDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<Bus> Buses { get; set; }

    public virtual DbSet<BusRoute> BusRoutes { get; set; }

    public virtual DbSet<Passenger> Passengers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=PC0443\\MSSQL2019;Database=TicketDB;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.BookingId).HasName("PK__BOOKING__73951AED40DAED38");

            entity.ToTable("BOOKING");

            entity.Property(e => e.BookingId).ValueGeneratedNever();
            entity.Property(e => e.BookingDate)
                .HasMaxLength(20)
                .IsUnicode(false);

            entity.HasOne(d => d.Bus).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.BusId)
                .HasConstraintName("FK__BOOKING__BusId__3A81B327");

            entity.HasOne(d => d.Passenger).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.PassengerId)
                .HasConstraintName("FK__BOOKING__Passeng__398D8EEE");
        });

        modelBuilder.Entity<Bus>(entity =>
        {
            entity.HasKey(e => e.BusId).HasName("PK__Bus__6A0F60B5319B7291");

            entity.ToTable("Bus");

            entity.Property(e => e.BusId).ValueGeneratedNever();
            entity.Property(e => e.SeatStatus)
                .HasMaxLength(10)
                .IsUnicode(false);

            entity.HasOne(d => d.Route).WithMany(p => p.Buses)
                .HasForeignKey(d => d.RouteId)
                .HasConstraintName("FK__Bus__RouteId__36B12243");
        });

        modelBuilder.Entity<BusRoute>(entity =>
        {
            entity.HasKey(e => e.RouteId).HasName("PK__BusRoute__80979B4DEE00D436");

            entity.Property(e => e.RouteId).ValueGeneratedNever();
            entity.Property(e => e.DropPoint)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.PickupPoint)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Passenger>(entity =>
        {
            entity.HasKey(e => e.PassengerId).HasName("PK__Passenge__88915FB021734122");

            entity.ToTable("Passenger");

            entity.Property(e => e.PassengerId).ValueGeneratedNever();
            entity.Property(e => e.PassengerName)
                .HasMaxLength(20)
                .IsUnicode(false);
        });


        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
