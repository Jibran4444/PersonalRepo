﻿using Assignment.Models;

using Microsoft.EntityFrameworkCore;

using System;
using System.Collections;
using System.Collections.Generic;

namespace Assignment.Models
{
    [Keyless]
    public class OrdersResult

    {

        public int Id { get; set; }
       
        public int CustomerId { get; set; }
        public DateTime OrderDate { get; set; }
        public int OrderAmount { get; set; }
       // public int OfferAmount { get; set; }
        public IEnumerable<OrderItem> OrderItems { get; set; }
    }
}

