﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Libary.Models;

public partial class LibraryContext : DbContext
{
    public LibraryContext()
    {
    }

    public LibraryContext(DbContextOptions<LibraryContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Author> Authors { get; set; }

    public virtual DbSet<Author1> Author1s { get; set; }

    public virtual DbSet<Book> Books { get; set; }

    public virtual DbSet<Client> Clients { get; set; }

    public virtual DbSet<Login> Logins { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=PC0577\\MSSQL2019;Database=library;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Author>(entity =>
        {
            entity.HasKey(e => e.AutherId).HasName("PK__Author__EED225222CEE5B17");

            entity.ToTable("Author");

            entity.Property(e => e.AutherId)
                .ValueGeneratedNever()
                .HasColumnName("autherId");
            entity.Property(e => e.AutherName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("autherName");
        });

        modelBuilder.Entity<Author1>(entity =>
        {
            entity.HasKey(e => e.AutherId).HasName("PK__Author1__EED2252237CE1CE5");

            entity.ToTable("Author1");

            entity.Property(e => e.AutherId)
                .ValueGeneratedNever()
                .HasColumnName("autherId");
            entity.Property(e => e.AutherName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("autherName");
        });

        modelBuilder.Entity<Book>(entity =>
        {
            entity.HasKey(e => e.BookId).HasName("PK__Book__8BE5A10DDECAE46B");

            entity.ToTable("Book");

            entity.Property(e => e.BookId)
                .ValueGeneratedNever()
                .HasColumnName("bookId");
            entity.Property(e => e.BookName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("bookName");
            entity.Property(e => e.ClientId).HasColumnName("clientId");

            entity.HasOne(d => d.Client).WithMany(p => p.Books)
                .HasForeignKey(d => d.ClientId)
                .HasConstraintName("FK__Book__clientId__38996AB5");

            entity.HasMany(d => d.Authers).WithMany(p => p.Books)
                .UsingEntity<Dictionary<string, object>>(
                    "BookAuthor",
                    r => r.HasOne<Author>().WithMany()
                        .HasForeignKey("AutherId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__BookAutho__authe__4222D4EF"),
                    l => l.HasOne<Book>().WithMany()
                        .HasForeignKey("BookId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__BookAutho__bookI__412EB0B6"),
                    j =>
                    {
                        j.HasKey("BookId", "AutherId").HasName("PK__BookAuth__B508835F3281E3F9");
                        j.ToTable("BookAuthor");
                        j.IndexerProperty<int>("BookId").HasColumnName("bookId");
                        j.IndexerProperty<int>("AutherId").HasColumnName("autherId");
                    });
        });

        modelBuilder.Entity<Client>(entity =>
        {
            entity.HasKey(e => e.ClientId).HasName("PK__Client__81A2CBE1BF344BC4");

            entity.ToTable("Client");

            entity.Property(e => e.ClientId)
                .ValueGeneratedNever()
                .HasColumnName("clientId");
            entity.Property(e => e.ClientName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("clientName");
        });

        modelBuilder.Entity<Login>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("LOGIN");

            entity.HasIndex(e => e.UserName, "UQ__LOGIN__C9F284562351C0E3").IsUnique();

            entity.Property(e => e.Password)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("password");
            entity.Property(e => e.Signup)
                .HasColumnType("datetime")
                .HasColumnName("signup");
            entity.Property(e => e.UserName)
                .HasMaxLength(41)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
