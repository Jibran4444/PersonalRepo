﻿using System;
using System.Collections.Generic;

namespace Libary.Models;

public partial class Login
{
    public string UserName { get; set; } = null!;

    public string? Password { get; set; }

    public DateTime? Signup { get; set; }
}
