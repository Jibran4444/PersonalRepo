﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Libary.Migrations
{
    /// <inheritdoc />
    public partial class ini1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Author",
                columns: table => new
                {
                    autherId = table.Column<int>(type: "int", nullable: false),
                    autherName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Author__EED225222CEE5B17", x => x.autherId);
                });

            migrationBuilder.CreateTable(
                name: "Client",
                columns: table => new
                {
                    clientId = table.Column<int>(type: "int", nullable: false),
                    clientName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Client__81A2CBE1BF344BC4", x => x.clientId);
                });

            migrationBuilder.CreateTable(
                name: "LOGIN",
                columns: table => new
                {
                    UserName = table.Column<string>(type: "varchar(41)", unicode: false, maxLength: 41, nullable: false),
                    password = table.Column<string>(type: "varchar(500)", unicode: false, maxLength: 500, nullable: true),
                    signup = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Book",
                columns: table => new
                {
                    bookId = table.Column<int>(type: "int", nullable: false),
                    bookName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    clientId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Book__8BE5A10DDECAE46B", x => x.bookId);
                    table.ForeignKey(
                        name: "FK__Book__clientId__38996AB5",
                        column: x => x.clientId,
                        principalTable: "Client",
                        principalColumn: "clientId");
                });

            migrationBuilder.CreateTable(
                name: "BookAuthor",
                columns: table => new
                {
                    bookId = table.Column<int>(type: "int", nullable: false),
                    autherId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__BookAuth__B508835F3281E3F9", x => new { x.bookId, x.autherId });
                    table.ForeignKey(
                        name: "FK__BookAutho__authe__4222D4EF",
                        column: x => x.autherId,
                        principalTable: "Author",
                        principalColumn: "autherId");
                    table.ForeignKey(
                        name: "FK__BookAutho__bookI__412EB0B6",
                        column: x => x.bookId,
                        principalTable: "Book",
                        principalColumn: "bookId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Book_clientId",
                table: "Book",
                column: "clientId");

            migrationBuilder.CreateIndex(
                name: "IX_BookAuthor_autherId",
                table: "BookAuthor",
                column: "autherId");

            migrationBuilder.CreateIndex(
                name: "UQ__LOGIN__C9F284562351C0E3",
                table: "LOGIN",
                column: "UserName",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BookAuthor");

            migrationBuilder.DropTable(
                name: "LOGIN");

            migrationBuilder.DropTable(
                name: "Author");

            migrationBuilder.DropTable(
                name: "Book");

            migrationBuilder.DropTable(
                name: "Client");
        }
    }
}
