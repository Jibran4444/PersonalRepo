﻿using System;
using System.Collections.Generic;

namespace Libary.Models;

public partial class Author1
{
    public int AutherId { get; set; }

    public string? AutherName { get; set; }
}
