﻿using Libary.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Libary.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    //public class ValuesController : ControllerBase
    //{
    //    private readonly LibraryContext _contex;
    //    private readonly IConfiguration _configure;

       
    //    public ValuesController(IConfiguration configuration)
    //    {
                
    //        _configure = configuration;
    //    }


    //    [HttpPost("login")]

    //    public ActionResult<string> login(user user)
    //    {
    //        var ob = _contex.Logins.FirstOrDefault(x => x.UserName==user.username);
    //        if(ob != null)
    //        {
    //            var token = "token";
    //            return Ok(token);
    //        }
    //        return Unauthorized("unotherize");
    //    }


    //    public string createToken(user user)
    //    {
    //        var sec = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configure.GetSection("Jwt:key").Value));
    //        var cre = new SigningCredentials(sec, SecurityAlgorithms.HmacSha256);
    //        var clames = new[] {

    //              new Claim(ClaimTypes.Name, user.username),
    //            new Claim(ClaimTypes.Role, "Admin")


    //        };
    //        var tok = new JwtSecurityToken(
    //            _configure.GetSection("Jwt:Issuer").Value,
    //            _configure.GetSection("Jwt:Audience").Value,
    //            clames,
    //            expires: DateTime.Now.AddMinutes(12),
    //            signingCredentials: cre
    //            );

    //        var token = new JwtSecurityTokenHandler().WriteToken(tok);

    //        return token;
    //    }
    //}
}
