﻿using System;
using System.Collections.Generic;

namespace Libary.Models;

public partial class Author
{
    public int AutherId { get; set; }

    public string? AutherName { get; set; }

    public virtual ICollection<Book> Books { get; set; } = new List<Book>();
}
