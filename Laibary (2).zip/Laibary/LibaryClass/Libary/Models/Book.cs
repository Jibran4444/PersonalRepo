﻿using System;
using System.Collections.Generic;

namespace Libary.Models;

public partial class Book
{
    public int BookId { get; set; }

    public string? BookName { get; set; }

    public int? ClientId { get; set; }

    public virtual Client? Client { get; set; }

    public virtual ICollection<Author> Authers { get; set; } = new List<Author>();
}
