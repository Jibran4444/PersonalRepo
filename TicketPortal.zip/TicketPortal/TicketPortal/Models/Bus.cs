﻿using System;
using System.Collections.Generic;

namespace TicketPortal.Models;

public partial class Bus
{
    public int BusId { get; set; }

    public int? RouteId { get; set; }

    public string? SeatStatus { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    public virtual BusRoute? Route { get; set; }
}
